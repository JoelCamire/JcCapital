# Signature JC Capital — v7 (style jccapital.ca)

Police Outfit, palette du site (#0A0908 / #22333B / #5E503F / #C6AC8F / #EAE0D5), dégradé or des boutons du site, vrai logo JC Capital.

## Fichiers

| Fichier | Usage |
|---|---|
| `signature-jccapital-complete.html` | Gmail (bannière et signature manuscrite animées) — images locales |
| `signature-jccapital-complete-HEBERGEE.html` | Même chose, images pointant vers `https://jccapital.ca/img/signature/` (la version à privilégier une fois les images en ligne) |
| `signature-jccapital-complete-PLUS-video-QR.html` (+ `-HEBERGEE`) | Version « bannière vivante » avec vignette vidéo « Joël en 60 secondes » et code QR Calendly |
| `signature-jccapital-Outlook.html` (+ `-HEBERGEE`) | Outlook (images fixes PNG, portrait sur fond blanc) |
| `signature-jccapital-courte.html` (+ `-HEBERGEE`) | Signature de réponse / transfert |
| `signature-mobile.txt` | Signature texte pour l'app Gmail / Outlook iPhone |
| `banniere-jccapital-animee.gif`, `banniere-jccapital.png` | Bannière animée (4 piliers) / fixe |
| `signature-manuscrite.gif`, `.png` | « Joël Camiré » manuscrit animé / fixe |
| `portrait-joel.png`, `portrait-joel-blanc.png` | Médaillon photo, anneau or (transparent / fond blanc) |
| `icon-linkedin.png`, `icon-linkedin-entreprise.png`, `icon-facebook.png`, `icon-instagram.png` | Icônes 30 px |
| `qr-rendezvous.png` | Code QR → Calendly, logo JC au centre |
| `video-joel-60s.png` | Vignette vidéo (lien actuel : chaîne YouTube @jccapital_ca — à remplacer par le lien de la vidéo quand elle existera) |

## Étape 1 — Mettre les images en ligne (10 min, une seule fois)

Les images sont déjà copiées dans ton dépôt du site : `C:\Users\JoëlCamiré\JcCapital\img\signature\`.

1. Ouvre le dossier `JcCapital` dans VS Code / GitHub Desktop.
2. Commit : « Ajout images signature courriel » puis push.
3. Vérifie que `https://jccapital.ca/img/signature/banniere-jccapital-animee.gif` s'affiche dans le navigateur.

Tant que ce n'est pas fait, utilise les fichiers **sans** `-HEBERGEE` (les images sont insérées manuellement, voir étape 2).

## Étape 2 — Gmail (ordinateur)

1. Ouvre `signature-jccapital-complete-HEBERGEE.html` dans Chrome (double-clic).
2. Ctrl+A puis Ctrl+C.
3. Gmail → ⚙ → **Voir tous les paramètres** → **Signature** → **Créer** → nom « JC Capital ».
4. Clique dans la zone, Ctrl+V. Vérifie que les images s'affichent (si une image apparaît comme texte, clique l'icône image de l'éditeur → **Adresse Web (URL)** → colle l'URL `https://jccapital.ca/img/signature/nom-du-fichier`).
5. **Valeurs par défaut** : nouveaux messages = « JC Capital »; réponses/transferts = crée une 2e signature « Courte » avec `signature-jccapital-courte-HEBERGEE.html`.
6. **Enregistrer les modifications** en bas de page.

## Étape 3 — Outlook (nouveau Outlook / Outlook Web)

1. Ouvre `signature-jccapital-Outlook-HEBERGEE.html` dans Chrome, Ctrl+A, Ctrl+C.
2. Outlook → ⚙ → **Comptes** → **Signatures** → **+ Nouvelle signature** → nom « JC Capital ».
3. Ctrl+V dans l'éditeur → **Enregistrer**.
4. Dans « Sélectionner les signatures par défaut » : nouveaux messages = JC Capital; réponses = Courte.

Outlook classique (bureau) : Fichier → Options → Courrier → **Signatures…** → Nouveau → coller → OK.

## Étape 4 — Téléphone

- App Gmail : ⚙ → ton compte → **Signature mobile** → colle le contenu de `signature-mobile.txt`.
- Outlook iPhone/Android : ⚙ → **Signature** → colle le même texte.

## Test

Envoie-toi un courriel à `joelcamire@jccapital.ca` ET à une adresse Gmail perso; vérifie : bannière animée, photo, 4 icônes cliquables, bouton Calendly, lien www.jccapital.ca.
